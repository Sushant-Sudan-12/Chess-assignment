﻿using System;
using UnityEngine;

namespace Chess.Scripts.Core {
    public class ChessPlayerPlacementHandler : MonoBehaviour {
        [SerializeField] public int row , column ;
        [SerializeField] public bool isEnemy;

        public int Row
        {
            get { return row; }
        }
        public int Column
        {
            get { return column; }
        }
        private void Start() {
            transform.position = ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position;
            ChessBoardPlacementHandler.Instance.AddPiece(row,column);
            if(isEnemy){
                ChessBoardPlacementHandler.Instance.AddEnemyPiece(row,column);
            }
        }
        
    }
}