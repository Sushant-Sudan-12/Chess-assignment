using UnityEngine;
using UnityEngine.InputSystem;

namespace Chess.Scripts.Core {
    public class InputHandler : MonoBehaviour
    {
        public int row , column ;
        public void OnClick(InputAction.CallbackContext context)
        {
            if (!context.started) return;

            var rayHit = Physics2D.GetRayIntersection(Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue()));
            if (!rayHit.collider) return;
            
            ChessPiece chessPiece = rayHit.collider.GetComponent<ChessPiece>();
            
            ChessPlayerPlacementHandler chessPlayerPlacement = rayHit.collider.GetComponent<ChessPlayerPlacementHandler>();
            if(chessPlayerPlacement.isEnemy) return;
            
            if (chessPlayerPlacement != null)
            {
                row = chessPlayerPlacement.Row;
                column = chessPlayerPlacement.Column;
            }
            if(chessPiece.pieceName == "Pawn"){
                chessPiece.isPawn(row,column);
                }
            else if(chessPiece.pieceName == "Bishop"){
                chessPiece.isBishop(row,column);
            }
            else if(chessPiece.pieceName == "Queen"){
                chessPiece.isQueen(row,column);
            }
            else if(chessPiece.pieceName == "Knight"){
                chessPiece.isKnight(row,column);
            }
            else if(chessPiece.pieceName == "Rook"){
                chessPiece.isRook(row,column);
            }
            else if(chessPiece.pieceName == "King"){
                chessPiece.isKing(row,column);
            }
        
        }
    }
}
