using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics.CodeAnalysis;


namespace  Chess.Scripts.Core{
    [SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
    public sealed class ChessBoardPlacementHandler : MonoBehaviour {
        [SerializeField] private GameObject[] _rowsArray;
        [SerializeField] private GameObject _highlightPrefab;
        [SerializeField] private GameObject _highlightEnemyPrefab;
        private GameObject[,] _chessBoard;
        private Dictionary<(int, int), bool> occupiedPositions = new Dictionary<(int, int), bool>();
        private Dictionary<(int, int), bool> occupiedEnemyPositions = new Dictionary<(int, int), bool>();
        

        internal static ChessBoardPlacementHandler Instance;

        private void Awake() {
            Instance = this;
            GenerateArray();
        }

        private void GenerateArray() {
            _chessBoard = new GameObject[8, 8];
            for (var i = 0; i < 8; i++) {
                for (var j = 0; j < 8; j++) {
                    _chessBoard[i, j] = _rowsArray[i].transform.GetChild(j).gameObject;
                }
            }
        }

        internal GameObject GetTile(int i, int j) {
            try {
                return _chessBoard[i, j];
            } catch (Exception) {
                Debug.LogError("Invalid row or column.");
                return null;
            }
        }

        internal void Highlight(int row, int col) {
            var tile = GetTile(row, col).transform;
            if (tile == null) {
                Debug.LogError("Invalid row or column.");
                return;
            }

            Instantiate(_highlightPrefab, tile.transform.position, Quaternion.identity, tile.transform);
        }

        internal void EnemyHighlight(int row, int col) {
            var tile = GetTile(row, col).transform;
            if (tile == null) {
                Debug.LogError("Invalid row or column.");
                return;
            }

            Instantiate(_highlightEnemyPrefab, tile.transform.position, Quaternion.identity, tile.transform);
        }

        internal void ClearHighlights() {
            for (var i = 0; i < 8; i++) {
                for (var j = 0; j < 8; j++) {
                    var tile = GetTile(i, j);
                    if (tile.transform.childCount <= 0) continue;
                    foreach (Transform childTransform in tile.transform) {
                        Destroy(childTransform.gameObject);
                    }
                }
            }
        }
        

        public void AddPiece(int row, int column) {
            var position = (row, column);

            if (!occupiedPositions.ContainsKey(position)) {
                occupiedPositions[position] = true;
            } else {
                Debug.LogError("A piece already exists at the target position.");
            }
        }

        public bool IsPieceAtPosition(int row, int column) {
            var position = (row, column);
            return occupiedPositions.ContainsKey(position);
        }


        public void RemovePiece(int row, int column) {
            var position = (row, column);
 
            if (occupiedPositions.ContainsKey(position)) {
                occupiedPositions.Remove(position);
            } else {
                Debug.LogError("No piece found at the target position.");
            }
        }

        public void AddEnemyPiece(int row, int column) {
            var position = (row, column);

            if (!occupiedEnemyPositions.ContainsKey(position)) {
                occupiedEnemyPositions[position] = true;
            } else {
                Debug.LogError("A piece already exists at the target position.");
            }
        }

        public bool IsEnemyPieceAtPosition(int row, int column) {
            var position = (row, column);
            return occupiedEnemyPositions.ContainsKey(position);
        }

        public void RemoveEnemyPiece(int row, int column) {
            var position = (row, column);
 
            if (occupiedEnemyPositions.ContainsKey(position)) {
                occupiedEnemyPositions.Remove(position);
            } else {
                Debug.LogError("No piece found at the target position.");
            }
        }



       


        #region Highlight Testing

        // private void Start() {
        //     StartCoroutine(Testing());
        // }

        // private IEnumerator Testing() {
        //     Highlight(2, 7);
        //     yield return new WaitForSeconds(1f);
        
        //     ClearHighlights();
        //     Highlight(2, 7);
        //     Highlight(2, 6);
        //     Highlight(2, 5);
        //     Highlight(2, 4);
        //     yield return new WaitForSeconds(1f);
        
        //     ClearHighlights();
        //     Highlight(7, 7);
        //     Highlight(2, 7);
        //     yield return new WaitForSeconds(1f);
        // }

        #endregion
    }
}