using System;
using UnityEngine;

namespace Chess.Scripts.Core {
    public class ChessPiece : MonoBehaviour
    {
        public string pieceName;

        public void isPawn(int row,int column){
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            if (row == 1){
                if (!ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column)){
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column);
                }
                if (!ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+2,column)){
                    ChessBoardPlacementHandler.Instance.Highlight(row+2, column);
                }
            }else{
                if (!ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column)){
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column);
                }
            }
            if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column+1)){
                ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column+1);
            }
            if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column-1)){
                ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column-1);
            }

        }

        public void isBishop(int row , int column){
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            for(int n =1;n<8;n++){
                if(row+n < 8 && column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column+n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >= 0  && column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column+n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row+n < 8 && column - n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column-n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >=0 && column - n >=0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column-n);
                    }
                }
            }
        }
        
        

        public void isRook(int row , int column){
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            
            for(int n =1;n<8;n++){
                
                if(row+n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(column - n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row, column-n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row, column+n);
                    }
                }
            }
        }

        public void isKnight(int row , int column){  
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            
            //Sorry couldn't come up with a better logic for knight
            
            if(row+2 >=0 && row+2 <8 && column-1 >=0 &&column-1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+2,column-1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+2,column-1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+2,column-1);
                    }
                
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+2, column-1);
                }
            }
            if(row+2 >=0 && row+2 <8 &&column+1 >=0 && column+1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+2,column+1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+2,column+1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+2,column+1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+2, column+1);
                }
            }
            if(row-2 >=0 && row-2 <8 &&column-1 >=0 &&column-1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-2,column-1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-2,column-1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-2,column-1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-2, column-1);
                }
            }
            if(row-2 >=0 && row-2 <8 &&column+1 >=0 && column+1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-2,column+1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-2,column+1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-2,column+1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-2, column+1);
                }
            }
            if(row+1 >=0 && row+1 <8 &&column-2 >=0 && column-2 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column-2)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column-2)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column-2);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column-2);
                }
            }
            if(row+1 >=0 && row+1 <8 &&column+2 >=0 && column+2 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column+2)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column+2)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column+2);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column+2);
                }
            }
            if(row-1 >=0 && row-1 <8 &&column-2 >=0 && column-2 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-1,column-2)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-1,column-2)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-1,column-2);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-1, column-2);
                }
            }
            if(row-1 >=0 && row-1 <8 &&column+2 >=0 && column+2 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-1,column+2)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-1,column+2)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-1,column+2);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-1, column+2);
                }
            }
        
        }
        
       
        public void isQueen(int row , int column){
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            for(int n =1;n<8;n++){
                
                if(row+n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(column - n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row, column-n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row, column+n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row+n < 8 && column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column+n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >= 0  && column + n < 8){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column+n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column+n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column+n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column+n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row+n < 8 && column - n >= 0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+n,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+n,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+n,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row+n, column-n);
                    }
                }
            }
            for(int n =1;n<8;n++){
                if(row-n >=0 && column - n >=0){
                    if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-n,column-n)){
                        if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-n,column-n)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row-n,column-n);
                        }
                        break;
                    }else{
                        ChessBoardPlacementHandler.Instance.Highlight(row-n, column-n);
                    }
                }
            }
        }

        public void isKing(int row , int column){
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            
            if(row+1 < 8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column)){
                            ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column);
                        }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column);
                }
            }
            if(row-1 >= 0){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-1,column)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-1,column)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-1,column);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-1, column);
                }
            }
            if(column+1 < 8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column+1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column+1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column+1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row, column+1);
                }
            }
            if(column-1 >= 0){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row,column-1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row,column-1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row,column-1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row, column-1);
                }
            }
            if(row+1 < 8 && column + 1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column+1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column+1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column+1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column+1);
                }
            }
            if(row+1 < 8 && column - 1 >= 0){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row+1,column-1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row+1,column-1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row+1,column-1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row+1, column-1);
                }
            }
            if(row-1 >= 0 && column + 1 <8){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-1,column+1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-1,column+1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-1,column+1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-1, column+1);
                }
            }
            if(row-1 >= 0 && column - 1 >= 0 ){
                if(ChessBoardPlacementHandler.Instance.IsPieceAtPosition(row-1,column-1)){
                    if(ChessBoardPlacementHandler.Instance.IsEnemyPieceAtPosition(row-1,column-1)){
                        ChessBoardPlacementHandler.Instance.EnemyHighlight(row-1,column-1);
                    }
                }else{
                    ChessBoardPlacementHandler.Instance.Highlight(row-1, column-1);
                }
            }            
        }  
    }
}